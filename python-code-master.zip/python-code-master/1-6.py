#Given an image represented by an NxN matrix, where each pixel 
#in the image is 4 bytes, write a method to rotate the image 
#by 90 degrees. Can you do this in place?

#wasted a little bit of time looking at NxM case and the 
#difficulties of doing it in place. interesting problem to 
#come back to

#not sure how they are defining the "matrix" data type
# assume it is an array of arrays, first being row number

def rotateByNintyDegrees(square_matrix):
	index = 0
	temp_pixel
	for i in range(1,4):
		square_matrix





