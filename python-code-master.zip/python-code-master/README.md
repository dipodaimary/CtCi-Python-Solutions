python-code
===========

A place for me to practice my coding skills and get some feedback
